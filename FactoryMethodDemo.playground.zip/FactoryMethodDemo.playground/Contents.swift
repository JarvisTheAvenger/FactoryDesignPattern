// Factory desing pattern

protocol Serializable {
    func serialize()
}

class JSONSerializer: Serializable {
    func serialize() {
        print("JSON ---> \(#function)")
    }

}

class XMLSerializer: Serializable {
    func serialize() {
        print("XML ---> \(#function)")
    }
}

class PropertyListSerializer: Serializable {
    func serialize() {
        print("PropetyList ---> \(#function)")
    }
}

enum SerializerType {
    case json
    case xml
    case propertyList
}

struct SerializerFactory {
    func makeSerializableObject(serializerType: SerializerType) -> Serializable {
        
        var result: Serializable
        
        switch serializerType {
        case .json:
            result = JSONSerializer()
        case .xml:
            result = XMLSerializer()
        case .propertyList:
            result = PropertyListSerializer()
        }
        
        return result
    }
}

let factory = SerializerFactory()
let xmlSerializer = factory.makeSerializableObject(serializerType: .xml)
